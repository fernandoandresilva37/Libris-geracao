# Líbris Geração — Servo de Cristo Fernando

Projeto Android (WebView) pronto para abrir no Android Studio.

## Conteúdo
- Bíblia completa por livros/capítulos (carregada pela API bible-api.com, tradução João Ferreira de Almeida)
- Orações
- Versículo do dia
- 7 devocionais
- Orientação cristã
- Favoritos salvos no aparelho
- Compartilhamento
- Ícone de Bíblia aberta + chama, inspirado no tema pentecostal

## Gerar o APK
Abra esta pasta no Android Studio, aguarde a sincronização do Gradle e use:
Build > Build APK(s).

O APK de debug normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Observação sobre a Bíblia
A versão usa a tradução Almeida oferecida pela bible-api.com. O serviço informa que disponibiliza João Ferreira de Almeida e recomenda não baixar a Bíblia inteira pela API; para uma versão offline/embutida, substitua a camada de dados por uma fonte com licença adequada. A edição Almeida 1819 é apontada como domínio público por fontes de referência.
